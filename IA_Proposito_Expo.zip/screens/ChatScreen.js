
import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Simulated API function (returns a promise)
function mockApiResponse(question) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ answer: `Resposta simulada para: "${question}"` });
    }, 700);
  });
}

export default function ChatScreen() {
  const [input, setInput] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [lastFeedbackSaved, setLastFeedbackSaved] = useState(null);

  const send = async () => {
    if (!input.trim()) {
      Alert.alert('Digite algo antes de enviar');
      return;
    }
    setLoading(true);
    const api = await mockApiResponse(input.trim());
    setResponse(api.answer);
    setLoading(false);

    // save to all interactions
    const record = {
      datetime: new Date().toISOString(),
      input: input.trim(),
      response: api.answer,
      useful: null
    };
    try {
      const raw = await AsyncStorage.getItem('@ia_proposito_all');
      const arr = raw ? JSON.parse(raw) : [];
      arr.unshift(record);
      await AsyncStorage.setItem('@ia_proposito_all', JSON.stringify(arr));
      setLastFeedbackSaved(null);
    } catch (e) {
      console.error(e);
    }
  };

  const giveFeedback = async (useful) => {
    // update last saved entry and optionally save to useful list
    try {
      const raw = await AsyncStorage.getItem('@ia_proposito_all');
      const arr = raw ? JSON.parse(raw) : [];
      if (arr.length === 0) return;
      arr[0].useful = useful;
      await AsyncStorage.setItem('@ia_proposito_all', JSON.stringify(arr));

      if (useful) {
        const rawU = await AsyncStorage.getItem('@ia_proposito_useful');
        const arrU = rawU ? JSON.parse(rawU) : [];
        arrU.unshift(arr[0]);
        await AsyncStorage.setItem('@ia_proposito_useful', JSON.stringify(arrU));
      }
      setLastFeedbackSaved(useful);
      Alert.alert('Feedback registrado');
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Digite sua mensagem</Text>
      <TextInput style={styles.input} value={input} onChangeText={setInput} placeholder="Ex: Quero registrar uma oração..." />
      <Button title="Enviar" onPress={send} />
      {loading && <ActivityIndicator style={{marginTop:10}} />}
      {response ? (
        <View style={styles.responseBox}>
          <Text style={styles.responseText}>{response}</Text>
          <Text style={{marginTop:10}}>A resposta foi útil?</Text>
          <View style={{flexDirection:'row', gap:10, marginTop:8}}>
            <Button title="Sim" onPress={() => giveFeedback(true)} />
            <View style={{width:10}} />
            <Button title="Não" onPress={() => giveFeedback(false)} />
          </View>
          {lastFeedbackSaved !== null && <Text style={{marginTop:8}}>Último feedback salvo: {lastFeedbackSaved ? 'Sim' : 'Não'}</Text>}
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {flex:1, padding:16},
  label: {fontSize:16, marginBottom:8},
  input: {borderWidth:1, borderColor:'#ccc', padding:10, marginBottom:10, borderRadius:6},
  responseBox: {marginTop:20, padding:12, backgroundColor:'#f2f2f2', borderRadius:8},
  responseText: {fontSize:16}
});
