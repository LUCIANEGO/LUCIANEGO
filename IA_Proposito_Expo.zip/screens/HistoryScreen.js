
import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, Button } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function HistoryScreen() {
  const [all, setAll] = useState([]);
  const [useful, setUseful] = useState([]);

  const load = async () => {
    const raw = await AsyncStorage.getItem('@ia_proposito_all');
    const arr = raw ? JSON.parse(raw) : [];
    setAll(arr);
    const rawU = await AsyncStorage.getItem('@ia_proposito_useful');
    const arrU = rawU ? JSON.parse(rawU) : [];
    setUseful(arrU);
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Histórico (todas as interações)</Text>
      <FlatList data={all} keyExtractor={(item, idx) => idx.toString()} renderItem={({item}) => (
        <View style={styles.item}>
          <Text style={styles.itemDate}>{item.datetime}</Text>
          <Text style={styles.itemInput}>{item.input}</Text>
          <Text style={styles.itemResp}>{item.response}</Text>
          <Text style={styles.itemUtil}>Útil: {item.useful === null ? '-' : (item.useful ? 'Sim' : 'Não')}</Text>
        </View>
      )} />
      <Text style={[styles.title, {marginTop:12}]}>Requisições Úteis</Text>
      <FlatList data={useful} keyExtractor={(item, idx) => 'u'+idx.toString()} renderItem={({item}) => (
        <View style={styles.item}>
          <Text style={styles.itemDate}>{item.datetime}</Text>
          <Text style={styles.itemInput}>{item.input}</Text>
          <Text style={styles.itemResp}>{item.response}</Text>
        </View>
      )} />
      <View style={{marginTop:12}}>
        <Button title="Recarregar" onPress={load} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {flex:1, padding:12},
  title: {fontSize:16, fontWeight:'bold', marginBottom:8},
  item: {padding:8, borderBottomWidth:1, borderBottomColor:'#eee'},
  itemDate: {fontSize:12, color:'#666'},
  itemInput: {fontSize:14, marginTop:4},
  itemResp: {fontSize:13, color:'#333', marginTop:4},
  itemUtil: {fontSize:12, color:'#333', marginTop:4}
});
