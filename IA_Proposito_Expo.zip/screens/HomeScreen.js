
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function HomeScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>IA Propósito</Text>
      <Text style={styles.subtitle}>Espiritual • Musical • Profissional • Bem-estar</Text>
      <Text style={styles.body}>Use a aba Chat para enviar perguntas e registrar feedback. O histórico fica na aba History.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {flex:1, justifyContent:'center', alignItems:'center', padding:20},
  title: {fontSize:28, fontWeight:'bold', marginBottom:10},
  subtitle: {fontSize:16, marginBottom:10, color:'#555'},
  body: {fontSize:14, textAlign:'center', color:'#333'}
});
